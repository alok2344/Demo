 
import { Component } from '@angular/core';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css']
})


export class AppComponent {
	title = 'Student Management CyberinyDemo';

	 
	studentsList = [
	{	
		id : 1,
		first_name : "Alok",
		last_name : "Thakur",
		email : "mpthakurr@gmail.com",
		phone : 9898098766,
		department : "IT"
	},
	{
		id : 2,
		first_name : "Abhishek",
		last_name : "Kumar",
		email : "Abhi@test.com",
		phone : 9090998989,
		department : "Economics"
	},
	{
		id : 3,
		first_name : "Kumar",
		last_name : "Manoj",
		email : "Manoj@gmail.com",
		phone : 9887879098,
		department : "Science"
	},
	{
		id : 4,
		first_name : "John",
		last_name : "Cena",
		email : "john@ymail.com",
		phone : 4455666655,
		department : "Arts"
	},
	{
		id : 5,
		first_name : "Rey",
		last_name : "mysterio",
		email : "rey@ymail.com",
		phone : 8777676789,
		department : "wrestling"
	}
	];

	constructor() {
		// Save students to localStorage
		localStorage.setItem('students', JSON.stringify(this.studentsList));
	}
}
 